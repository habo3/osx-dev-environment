#include <QuickTime/QuickTimeMusic.k.h>
