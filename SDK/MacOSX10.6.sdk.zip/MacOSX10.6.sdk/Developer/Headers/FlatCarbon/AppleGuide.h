#warning AppleGuide.h is not available on Mac OS X
